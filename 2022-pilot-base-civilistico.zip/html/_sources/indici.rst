.. include:: report.rst
    :start-after: .. _start-roles:
    :end-before: .. _end-roles:

.. include:: report.rst
    :start-after: .. _start-replaces:
    :end-before: .. _end-replaces:

.. include:: report.rst
    :start-after: .. _start-indici:
    :end-before: .. _end-indici: