.. include:: report.rst
    :start-after: .. _start-roles:
    :end-before: .. _end-roles:

.. include:: report.rst
    :start-after: .. _start-replaces:
    :end-before: .. _end-replaces:

.. include:: report.rst
    :start-after: .. _start-glossary:
    :end-before: .. _end-glossary: