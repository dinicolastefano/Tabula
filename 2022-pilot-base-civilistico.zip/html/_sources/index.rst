****
Home
****

.. include:: first.rst

.. toctree::
    :maxdepth: 1
    :hidden:
    :name: mastertoc

    intro
    executive
    stato_patrimoniale
    conto_economico
    rendiconto
    indici
    crisi
    mcc
    glossary
