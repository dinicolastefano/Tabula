.. include:: report.rst
    :start-after: .. _start-roles:
    :end-before: .. _end-roles:

.. include:: report.rst
    :start-after: .. _start-replaces:
    :end-before: .. _end-replaces:

.. include:: report.rst
    :start-after: .. _start-conto_economico:
    :end-before: .. _end-conto_economico: